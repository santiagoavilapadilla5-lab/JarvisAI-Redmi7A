package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(5, 13, 28)
    private val cyan = Color.rgb(80, 210, 255)
    private val white = Color.rgb(230, 242, 255)
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speechReady = false
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        append("JARVIS", "Sistemas en línea. Soy JARVIS. Pulsa el micrófono para hablar o escribe un mensaje.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        }
        val subtitle = TextView(this).apply {
            text = "ASISTENTE PERSONAL • PROTOTIPO 1"
            textSize = 11f
            setTextColor(Color.rgb(135, 180, 210))
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 20)
        }
        transcript = TextView(this).apply {
            textSize = 15f
            setTextColor(white)
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(10, 27, 47))
            addView(transcript)
        }
        input = EditText(this).apply {
            hint = "Escribe una orden..."
            setHintTextColor(Color.rgb(125, 155, 180))
            setTextColor(white)
            setSingleLine(true)
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(19, 42, 65))
        }
        val send = makeButton("ENVIAR")
        send.setOnClickListener {
            val msg = input.text.toString().trim()
            if (msg.isNotEmpty()) {
                input.setText("")
                hideKeyboard()
                handleMessage(msg)
            }
        }
        val mic = makeButton("🎙  HABLAR")
        mic.setOnClickListener { startListening() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(mic, LinearLayout.LayoutParams(0, 52, 1f).apply { marginEnd = 8 })
            addView(send, LinearLayout.LayoutParams(0, 52, 1f))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 12 })
        root.addView(row, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8 })
        setContentView(root)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.BLACK)
        setBackgroundColor(cyan)
    }

    private fun append(who: String, text: String) {
        transcript.append("$who\n$text\n\n")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "El reconocimiento de voz no está disponible en este dispositivo.", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { runOnUiThread { append("JARVIS", "Te escucho...") } }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { runOnUiThread { Toast.makeText(this@MainActivity, "No pude reconocer la voz. Intenta otra vez.", Toast.LENGTH_SHORT).show() } }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) runOnUiThread { handleMessage(spoken) }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con JARVIS")
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo iniciar el micrófono.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleMessage(message: String) {
        append("TÚ", message)
        val lower = message.lowercase(Locale.ROOT)
        val reply = when {
            lower.contains("hola") -> "A sus órdenes. ¿Qué necesitas?"
            lower.contains("quién eres") || lower.contains("quien eres") -> "Soy JARVIS, tu asistente personal. Esta es mi primera versión."
            lower.contains("hora") -> "Puedes consultar la hora en la barra superior de tu teléfono. En una siguiente versión puedo añadir la hora dentro de la aplicación."
            lower.contains("ayuda") -> "Puedes saludarme, preguntarme quién soy o escribirme cualquier mensaje. La conexión a inteligencia artificial se configura en una versión posterior."
            else -> "He recibido tu mensaje. Para responder con inteligencia artificial real, falta configurar un proveedor de IA y un servidor seguro. No pongas claves secretas dentro de la aplicación."
        }
        append("JARVIS", reply)
        if (speechReady) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
        } catch (_: Exception) {}
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("es", "CO"))
            speechReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!speechReady) tts.setLanguage(Locale("es", "ES"))
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
